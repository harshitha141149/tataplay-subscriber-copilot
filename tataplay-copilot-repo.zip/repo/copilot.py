"""Retention Copilot: builds a validated retention brief for each priority subscriber."""
import json
import os
import sqlite3
from typing import Literal

import joblib
import mock_llm
import numpy as np
import pandas as pd
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel

import rag
from features import FEATURES, build_feature_row
from validated import invoke_with_retry

POLICY_FILES = set(rag.load_policies())
SYSTEM = ("RETENTION BRIEF. You write retention briefs for the retention desk. Reply with one JSON object only, with the keys "
          "subscriber_id, risk_band, recommended_action and policy_source. Use only the policy context provided.")


class RetentionBrief(BaseModel):
    """Validated retention brief returned by the model."""
    subscriber_id: str
    risk_band: Literal["High", "Medium", "Low"]
    recommended_action: str
    policy_source: str


parser = PydanticOutputParser(pydantic_object=RetentionBrief)
prompt = ChatPromptTemplate.from_messages([("system", "{system}"), ("human", "{facts}")])

con = sqlite3.connect("data/tataplay.db")
model = joblib.load("outputs/churn_model.joblib")
segments = pd.read_csv("outputs/segments.csv").set_index("subscriber_id")
scores = pd.read_csv("outputs/test_scores.csv").set_index("subscriber_id")
col = rag.build_collection(400, 60)


def risk_band(p):
    """High if p >= 0.40, Medium if p >= 0.20, otherwise Low."""
    return "High" if p >= 0.40 else ("Medium" if p >= 0.20 else "Low")


def build_brief(subscriber_id):
    """Build, validate and return the retention brief record for one subscriber."""
    tenure = int(con.execute("SELECT tenure_months FROM subscribers WHERE subscriber_id = ?", (subscriber_id,)).fetchone()[0])
    n_failed = int(con.execute("SELECT COUNT(*) FROM recharges WHERE subscriber_id = ? AND status = 'failed'",
                               (subscriber_id,)).fetchone()[0])
    row = build_feature_row(subscriber_id, con)
    assert int(row.tenure_months.iloc[0]) == tenure and int(row.n_failed_6m.iloc[0]) == n_failed
    rescored = float(model.predict_proba(row[FEATURES])[:, 1][0])
    prob = float(scores.loc[subscriber_id, "churn_probability"])
    assert round(rescored, 4) == round(prob, 4), (subscriber_id, rescored, prob)
    band = risk_band(prob)
    segment = segments.loc[subscriber_id, "segment_name"]
    hits = rag.retrieve(f"retention offer for a {band} risk subscriber with {tenure} months tenure and {n_failed} failed recharges", 3, col)
    facts = (f"FACTS:\nsubscriber_id: {subscriber_id}\nrisk_band: {band}\ntenure_months: {tenure}\n"
             f"failed_recharges_6m: {n_failed}\nsegment: {segment}\n\nPOLICY CONTEXT:\n{rag.context_block(hits)}")

    def check(rec):
        """Consistency checks against what was sent."""
        if rec.subscriber_id != subscriber_id:
            raise ValueError(f"subscriber_id {rec.subscriber_id} != {subscriber_id}")
        if rec.risk_band != band:
            raise ValueError(f"risk_band {rec.risk_band} != {band}")
        if rec.policy_source not in POLICY_FILES:
            raise ValueError(f"policy_source {rec.policy_source} is not a real policy file")

    rec, attempts, _ = invoke_with_retry(prompt, {"system": SYSTEM, "facts": facts}, parser, max_retries=2,
                                         post_check=check, echo_original=True)
    return {"subscriber_id": subscriber_id, "churn_probability": round(prob, 4), "segment": segment,
            "facts": {"risk_band": band, "tenure_months": tenure, "failed_recharges_6m": n_failed},
            "status": "valid" if rec else "manual_review", "attempts": attempts,
            "brief": json.loads(rec.model_dump_json()) if rec else None}


def expected_action(band, tenure, n_failed):
    """Rule verifiable from the policy text."""
    if band != "High":
        return "No retention offer applies"
    if n_failed >= 3:
        return "auto-renew setup call"
    return "loyalty discount of 15 percent" if tenure >= 12 else "free add-on pack for 2 months"


if __name__ == "__main__":
    mock_llm.reset()
    ids = pd.read_csv("outputs/retention_priority.csv").subscriber_id.tolist()
    out = [build_brief(s) for s in ids]
    with open("outputs/retention_briefs.jsonl", "w") as f:
        for r in out:
            f.write(json.dumps(r) + "\n")
    valid = [r for r in out if r["status"] == "valid"]
    print("valid briefs:", len(valid), "of", len(out))
    print(pd.Series([r["facts"]["risk_band"] for r in out]).value_counts().to_string())
    print(pd.Series([r["brief"]["recommended_action"] for r in valid]).value_counts().to_string())
    print("\nsubscriber | prob | band | tenure | failed | action | source | rule ok")
    for r in valid:
        f, b = r["facts"], r["brief"]
        ok = expected_action(f["risk_band"], f["tenure_months"], f["failed_recharges_6m"]).split()[0].lower() in b["recommended_action"].lower()
        print(r["subscriber_id"], r["churn_probability"], f["risk_band"], f["tenure_months"], f["failed_recharges_6m"],
              b["recommended_action"], b["policy_source"], ok)
