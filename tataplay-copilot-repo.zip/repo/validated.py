"""Parse-and-retry helper shared by the ticket extractor and the retention copilot."""
import json

from langchain_core.messages import AIMessage, HumanMessage

import llm_client as C


def invoke_with_retry(prompt, inputs, parser, max_retries=2, post_check=None, echo_original=False):
    """Run prompt | llm_fn | parser; on a parse error retry up to max_retries times.

    Each retry appends the model's bad reply as an assistant message and a user message that
    starts with "VALIDATION ERROR:" plus the error text. post_check(record) may raise ValueError
    for extra consistency rules. Returns (record or None, attempts, first_error or None).
    With echo_original the original user message is repeated after the error text.
    """
    chain = prompt | C.llm_fn | parser
    base = prompt.invoke(inputs)
    original_user = [m for m in base.to_messages() if m.type == "human"][0].content
    extra, first_error = [], None
    for attempt in range(1, max_retries + 2):
        bad_reply = None
        try:
            if attempt == 1:
                rec = chain.invoke(inputs)
            else:
                from langchain_core.prompt_values import ChatPromptValue
                reply = C.llm_fn(ChatPromptValue(messages=base.to_messages() + extra))
                bad_reply = reply
                rec = parser.parse(reply)
            if post_check:
                bad_reply = rec.model_dump_json()
                post_check(rec)
            return rec, attempt, first_error
        except Exception as e:  # parse, validation or consistency failure
            if first_error is None:
                first_error = e
            if bad_reply is None:
                bad_reply = getattr(e, "llm_output", "")
                if not isinstance(bad_reply, str):
                    bad_reply = json.dumps(bad_reply)
            err = f"VALIDATION ERROR: {e}"
            if echo_original:
                err += "\n" + original_user
            extra += [AIMessage(content=bad_reply or ""), HumanMessage(content=err)]
    return None, max_retries + 1, first_error
