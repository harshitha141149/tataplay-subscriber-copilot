#!/usr/bin/env bash
# Runs every stage in order and saves the console output of each stage under logs/.
set -e
mkdir -p logs
python generate_data.py            | tee logs/generate.txt
python part_a.py                   | tee logs/part_a.txt
python part_b.py                   | tee logs/part_b.txt
python part_c.py                   | tee logs/part_c.txt
python part_d1_client.py           | tee logs/part_d1.txt
python part_d2_classify.py         | tee logs/part_d2.txt
python part_d3_extract.py          | tee logs/part_d3.txt
python part_d4_rag.py              | tee logs/part_d4.txt
python copilot.py                  | tee logs/part_d5.txt
