"""Part D task 1: demonstrations of the client's behaviour."""
import mock_llm
import llm_client as C

H = {"Authorization": "Bearer x", "Content-Type": "application/json"}
P = {"model": "m", "messages": [{"role": "user", "content": "hi"}]}

mock_llm.reset()
print("(a) no Authorization header ->", mock_llm.post(mock_llm.URL, headers={}, json=P).status_code)
mock_llm.reset()
print("(a) wrong URL ->", mock_llm.post("https://wrong.example/x", headers=H, json=P).status_code)
mock_llm.reset()
try:
    C.call_llm([])  # empty messages -> 400, no retry
except C.LLMError as e:
    print("(a) call_llm with empty messages raises:", e, "| posts made:", mock_llm._state["calls"])

mock_llm.reset()
C.call_llm([{"role": "user", "content": "Tell me about yourself please."}], max_tokens=3)
print("(b) max_tokens=3 -> finish_reason:", C.last_call["finish_reason"])

mock_llm.reset()
sys_ = {"role": "system", "content": "You are helpful."}
print("(c) alone:", C.call_llm([sys_, {"role": "user", "content": "What is my name?"}]))
print("(c) with history:", C.call_llm([sys_, {"role": "user", "content": "My name is Asha."},
                                       {"role": "assistant", "content": "Nice to meet you, Asha."},
                                       {"role": "user", "content": "What is my name?"}]))

mock_llm.reset()
C.stats["recovered_429"] = 0
for _ in range(30):
    C.call_llm([{"role": "user", "content": "hello"}])
print("(d) 30 calls -> rate limits recovered:", C.stats["recovered_429"], "| total posts:", mock_llm._state["calls"])
