"""Part A: audit raw exports, clean them, store them in SQLite and run the four SQL queries."""
import os
import re
import sqlite3

import numpy as np
import pandas as pd

RAW, CLEAN = "data/raw", "data/clean"
os.makedirs(CLEAN, exist_ok=True)
os.makedirs("sql", exist_ok=True)

subs = pd.read_csv(f"{RAW}/subscribers.csv")
rech = pd.read_csv(f"{RAW}/recharges.csv")
plans = pd.read_csv(f"{RAW}/plans.csv")


def audit(df, name):
    """Print shape, dtypes and missing counts for a raw table."""
    print(f"\n=== {name}: shape {df.shape}")
    out = pd.DataFrame({"dtype": df.dtypes.astype(str), "missing": df.isna().sum(),
                        "missing_pct": (df.isna().mean() * 100).round(2)})
    print(out.to_string())


audit(subs, "subscribers (raw)")
audit(rech, "recharges (raw)")

print("\n--- audit figures")
print("subscribers rows", len(subs), "| exact dup rows", subs.duplicated().sum(),
      "| distinct ids", subs.subscriber_id.nunique())
print("blank age", subs.age.isna().sum(), "| age outside 10-100", ((subs.age < 10) | (subs.age > 100)).sum(),
      "| blank payment_mode", subs.payment_mode.isna().sum(),
      "| distinct raw city", subs.city.nunique(), "| distinct raw auto_renew", subs.auto_renew.nunique(),
      "| blank next_cycle", subs.next_cycle_recharge_inr.isna().sum())
non_num = pd.to_numeric(rech.amount_inr, errors="coerce").isna().sum()
print("recharges rows", len(rech), "| exact dup rows", rech.duplicated().sum(),
      "| distinct recharge_id", rech.recharge_id.nunique(), "| non-numeric amount", non_num,
      "| distinct raw status", rech.status.nunique(),
      "| orphan subscriber rows", (~rech.subscriber_id.isin(subs.subscriber_id)).sum())

# ---------------------------------------------------------------- clean subscribers
s = subs.drop_duplicates().copy()
print("\nsubscribers after dedupe:", len(s))
CITY = {"bangalore": "Bengaluru", "bombay": "Mumbai", "madras": "Chennai", "calcutta": "Kolkata",
        "new delhi": "Delhi", "hyd": "Hyderabad"}
c = s.city.str.strip().str.lower()
s["city"] = c.map(lambda x: CITY.get(x, x.title()))
s["auto_renew"] = s.auto_renew.str.strip().str.lower().map({"y": "Yes", "yes": "Yes", "n": "No", "no": "No"})
bad_age = (s.age < 10) | (s.age > 100)
print("ages set to missing:", int(bad_age.sum()))
s.loc[bad_age, "age"] = np.nan
print(s.city.value_counts().to_string())
print(s.auto_renew.value_counts().to_string())
print("missing age", s.age.isna().sum(), "| missing payment_mode", s.payment_mode.isna().sum(),
      "| churned", s.churned.sum(), f"({s.churned.mean() * 100:.2f}%)")

# ---------------------------------------------------------------- clean recharges
r = rech.drop_duplicates().copy()
n_dup = len(rech) - len(r)
r = r[r.subscriber_id.isin(s.subscriber_id)].copy()
print("\nrecharges after dedupe + orphan removal:", len(r), "(dups removed", n_dup, ")")
r["status"] = r.status.str.lower()
num = pd.to_numeric(r.amount_inr, errors="coerce")
bad = num.isna()
monthly = r.subscriber_id.map(s.set_index("subscriber_id").monthly_recharge_inr)
num[bad] = monthly[bad]
r["amount_inr"] = num
print("amounts rebuilt:", int(bad.sum()))
r["recharge_date"] = pd.to_datetime(r.recharge_date)
print(r.status.value_counts().to_string())
print("total successful amount:", r.loc[r.status == "success", "amount_inr"].sum())

s.to_csv(f"{CLEAN}/subscribers.csv", index=False)
r.assign(recharge_date=r.recharge_date.dt.strftime("%Y-%m-%d")).to_csv(f"{CLEAN}/recharges.csv", index=False)
plans.to_csv(f"{CLEAN}/plans.csv", index=False)

# ---------------------------------------------------------------- SQLite
if os.path.exists("data/tataplay.db"):
    os.remove("data/tataplay.db")
con = sqlite3.connect("data/tataplay.db")
s.to_sql("subscribers", con, index=False)
r2 = r.assign(recharge_date=r.recharge_date.dt.strftime("%Y-%m-%d"))
r2.to_sql("recharges", con, index=False)
plans.to_sql("plans", con, index=False)

sql_text = open("sql/queries.sql").read()
queries = {m.group(1): m.group(2).strip() for m in re.finditer(r"-- (Q\d)[^\n]*\n(.*?)(?=\n-- Q\d|\Z)", sql_text, re.S)}
for q, text in queries.items():
    df = pd.read_sql_query(text.rstrip(";"), con)
    print(f"\n##### {q}: {len(df)} rows")
    if q == "Q3":
        print("rank-1 per city:\n", df[df.rnk == 1].groupby("city").size().to_string())
        print("row_number=1 per city:\n", df[df.row_num == 1].groupby("city").size().to_string())
        print(df[df.city == "Kolkata"].head(4).to_string(index=False))
    elif q == "Q2":
        print("subscribers:", len(df), "| tenure 0:", int((df.tenure_months == 0).sum()))
    else:
        print(df.to_string(index=False))

# pandas confirmation of one Q1 row
chk = (r[r.status == "success"].merge(s[["subscriber_id", "plan_id"]], on="subscriber_id")
       .merge(plans, on="plan_id").groupby("plan_name").amount_inr.agg(["sum", "mean"]))
print("\npandas check (Premium):", chk.loc["Premium"].round(2).to_dict(),
      "| distinct subs:", r[r.status == "success"].merge(s[["subscriber_id", "plan_id"]], on="subscriber_id")
      .merge(plans, on="plan_id").query("plan_name == 'Premium'").subscriber_id.nunique())
con.close()
