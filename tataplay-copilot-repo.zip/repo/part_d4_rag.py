"""Part D task 4: chunking, retrieval evaluation, calibrated grounded answers and chunk-size experiment."""
import re

import mock_llm
import pandas as pd

import rag

ev = pd.read_csv("data/raw/policy_eval.csv").fillna("")
ans = ev[ev.expected_file != ""]
unans = ev[ev.expected_file == ""]

# (a) chunking
pol = rag.load_policies()
print("(a) chunks per file:", {f: len(rag.chunk_text(t)) for f, t in pol.items()}, "| total", sum(len(rag.chunk_text(t)) for t in pol.values()))

# (b)/(c) embed, retrieve, evaluate
ef = rag.get_embedder()
print("embedding function used:", rag.get_embedder.used)
col = rag.build_collection(400, 60, ef)
print("collection chunks:", col.count())
top = {q: rag.retrieve(q, 3, col) for q in ev.question}
hit3 = sum(any(h["source"] == r.expected_file for h in top[r.question]) for r in ans.itertuples())
hit1 = sum(top[r.question][0]["source"] == r.expected_file for r in ans.itertuples())
sa = [top[q][0]["similarity"] for q in ans.question]
su = [top[q][0]["similarity"] for q in unans.question]
print(f"(c) answerable: top-3 file hit {hit3}/12 | top-1 file hit {hit1}/12 | top-1 similarity {min(sa):.3f}..{max(sa):.3f} (mean {sum(sa)/len(sa):.3f})")
print("    unanswerable top-1 similarities:", [round(x, 3) for x in su])
for r in unans.itertuples():
    print(f"      {top[r.question][0]['similarity']:.3f}  {r.question}")

STOP = mock_llm.STOP
words = lambda t: set(re.findall(r"[a-z]+", t.lower())) - STOP
fw = {f: words(t) for f, t in pol.items()}
kw_ok = 0
for r in ans.itertuples():
    q = words(r.question)
    best = sorted(fw, key=lambda f: (-len(q & fw[f]), f))[0]
    kw_ok += best == r.expected_file
print(f"    keyword baseline top-1 correct: {kw_ok}/12")

# (d) threshold + grounded vs ungrounded
thr = (min(sa) + max(su)) / 2
print(f"(d) threshold = midpoint({min(sa):.3f}, {max(su):.3f}) = {thr:.3f}; margin window = {min(sa) - max(su):.3f}")
rows, fact_ok, fb_ok = [], 0, 0
mock_llm.reset()
for r in ev.itertuples():
    g, hits = rag.answer(r.question, col, thr, grounded=True)
    u, _ = rag.answer(r.question, col, thr, grounded=False)
    if r.expected_file:
        fact_ok += r.expected_fact in " ".join(g.split())
    else:
        fb_ok += g == rag.FALLBACK
    rows.append(dict(question=r.question, expected_file=r.expected_file, top1_source=hits[0]["source"],
                     top1_similarity=round(hits[0]["similarity"], 4),
                     hit_at_3=any(h["source"] == r.expected_file for h in hits) if r.expected_file else "",
                     grounded_answer=" ".join(g.split()), ungrounded_answer=u))
pd.DataFrame(rows).to_csv("outputs/rag_eval.csv", index=False)
print(f"    grounded answers containing expected fact: {fact_ok}/12 | unanswerable getting fallback: {fb_ok}/4")
print("    distinct ungrounded answers:", len({x['ungrounded_answer'] for x in rows}))

# (e) chunk size
col2 = rag.build_collection(200, 30, ef)
norm = lambda s: " ".join(s.split())
in_top3, fact2 = 0, 0
mock_llm.reset()
for r in ans.itertuples():
    hits = rag.retrieve(r.question, 3, col2)
    in_top3 += r.expected_fact in norm(" ".join(h["text"] for h in hits))
    g, _ = rag.answer(r.question, col2, thr, grounded=True)
    fact2 += r.expected_fact in norm(g)
print(f"(e) 200/30: chunks {col2.count()} | fact in top-3 chunks {in_top3}/12 | grounded answers with fact {fact2}/12")
