"""Part B: churn prediction with leakage check, tuning, cost-based threshold and a single test evaluation."""
import json
import os

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

from features import CAT, FEATURES, LEAKY, NUM, add_recharge_features

os.makedirs("outputs", exist_ok=True)
COST_MISS, COST_OFFER = 1200, 300

subs = pd.read_csv("data/clean/subscribers.csv")
rech = pd.read_csv("data/clean/recharges.csv")
df = add_recharge_features(subs, rech)
print("class balance:", int(df.churned.sum()), "of", len(df), f"({df.churned.mean() * 100:.2f}%)")
print("recency_days missing:", int(df.recency_days.isna().sum()))

X, y = df[FEATURES + LEAKY + ["subscriber_id"]], df["churned"]
X_tmp, X_test, y_tmp, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_tmp, y_tmp, test_size=0.25, stratify=y_tmp, random_state=42)
print("split sizes train/val/test:", len(X_train), len(X_val), len(X_test),
      "| churners:", int(y_train.sum()), int(y_val.sum()), int(y_test.sum()))


def make_pre(num=NUM, cat=CAT):
    """ColumnTransformer: median+scale for numeric, most-frequent+one-hot for categorical."""
    return ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                          ("oh", OneHotEncoder(handle_unknown="ignore"))]), cat)])


def rf(**kw):
    """Random forest pipeline on the legitimate 16 features."""
    return Pipeline([("pre", make_pre()), ("model", RandomForestClassifier(random_state=42, **kw))])


def report(name, pipe, X_, y_):
    """Accuracy, precision, recall, F1 (churn class)."""
    p = pipe.predict(X_[FEATURES])
    return dict(model=name, acc=accuracy_score(y_, p), prec=precision_score(y_, p, zero_division=0),
                rec=recall_score(y_, p), f1=f1_score(y_, p))


# ---------------------------------------------------------------- leakage experiment
print("\n--- leakage experiment (RF, validation)")
leaky_pre = ColumnTransformer([
    ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), NUM + ["next_cycle_recharge_inr"]),
    ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")), ("oh", OneHotEncoder(handle_unknown="ignore"))]),
     CAT + ["closure_request_logged"])])
leaky = Pipeline([("pre", leaky_pre), ("model", RandomForestClassifier(n_estimators=100, random_state=42))])
leaky.fit(X_train, y_train)
pl = leaky.predict(X_val)
clean_rf = rf(n_estimators=100).fit(X_train[FEATURES], y_train)
pc = clean_rf.predict(X_val[FEATURES])
print(f"with leakage:    acc {accuracy_score(y_val, pl):.3f}  F1 {f1_score(y_val, pl):.3f}")
print(f"without leakage: acc {accuracy_score(y_val, pc):.3f}  F1 {f1_score(y_val, pc):.3f}")

# ---------------------------------------------------------------- preprocessing statistics
print("\n--- preprocessing (fit on train only)")
pre = make_pre().fit(X_train[FEATURES])
Z = pre.transform(X_train[FEATURES])
Z = Z.toarray() if hasattr(Z, "toarray") else Z
print("output columns:", Z.shape[1], "| NaN left after transform:", int(np.isnan(Z).sum()))
print("learned median age:", pre.named_transformers_["num"]["imp"].statistics_[NUM.index("age")])
print("scaler mean tenure (train):", round(pre.named_transformers_["num"]["sc"].mean_[0], 2),
      "| full-data mean tenure:", round(df.tenure_months.mean(), 2))

# ---------------------------------------------------------------- baselines and simple models
print("\n--- validation baselines")
maj = np.zeros(len(y_val), dtype=int)
print(f"majority: acc {accuracy_score(y_val, maj):.3f} F1 {f1_score(y_val, maj, zero_division=0):.3f}")
lr0 = Pipeline([("pre", make_pre()), ("model", LogisticRegression(max_iter=1000))]).fit(X_train[FEATURES], y_train)
print({k: (round(v, 3) if not isinstance(v, str) else v) for k, v in report("logreg", lr0, X_val, y_val).items()})
dt0 = Pipeline([("pre", make_pre()), ("model", DecisionTreeClassifier(random_state=42))]).fit(X_train[FEATURES], y_train)
print(f"tree unrestricted: train acc {dt0.score(X_train[FEATURES], y_train):.3f}  val F1 {f1_score(y_val, dt0.predict(X_val[FEATURES])):.3f}")
print(f"forest default:    train acc {clean_rf.score(X_train[FEATURES], y_train):.3f}  val F1 {f1_score(y_val, pc):.3f}")
print("depth | train acc | val F1")
for d in range(1, 11):
    t = Pipeline([("pre", make_pre()), ("model", DecisionTreeClassifier(max_depth=d, random_state=42))]).fit(X_train[FEATURES], y_train)
    print(f"{d:5d} | {t.score(X_train[FEATURES], y_train):.3f}     | {f1_score(y_val, t.predict(X_val[FEATURES])):.3f}")

# ---------------------------------------------------------------- tuning
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
lr_pipe = Pipeline([("pre", make_pre()), ("model", LogisticRegression(max_iter=1000))])
gs_lr = GridSearchCV(lr_pipe, {"model__C": [0.01, 0.1, 1, 10, 100]}, cv=cv, scoring="f1").fit(X_train[FEATURES], y_train)
rf_pipe = Pipeline([("pre", make_pre()), ("model", RandomForestClassifier(random_state=42))])
grid_rf = {"model__n_estimators": [50, 100, 150], "model__max_depth": [3, 4, 5, 6, 8], "model__max_features": [3, 4, 5]}
gs_rf = GridSearchCV(rf_pipe, grid_rf, cv=cv, scoring="f1").fit(X_train[FEATURES], y_train)
print("\n--- tuning")
for n, g, combos in (("logreg", gs_lr, 5), ("forest", gs_rf, 45)):
    i = g.best_index_
    print(f"{n}: combos {combos}, fits {combos * 5}, best {g.best_params_}, "
          f"CV F1 {g.cv_results_['mean_test_score'][i]:.3f} (std {g.cv_results_['std_test_score'][i]:.3f})")
print("logreg CV F1 by C:", dict(zip([0.01, 0.1, 1, 10, 100], gs_lr.cv_results_["mean_test_score"].round(3))))

# ---------------------------------------------------------------- thresholds (validation only)
THR = np.round(np.arange(0.10, 0.901, 0.05), 2)


def cost(y_true, pred):
    """Total cost: 1200 per missed churner plus 300 per needless offer."""
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return COST_MISS * fn + COST_OFFER * fp


models = {"random_forest": gs_rf.best_estimator_, "logistic_regression": gs_lr.best_estimator_}
best_thr, val_cost = {}, {}
print("\n--- validation cost curves")
for n, m in models.items():
    pv = m.predict_proba(X_val[FEATURES])[:, 1]
    costs = [cost(y_val, (pv >= t).astype(int)) for t in THR]
    k = int(np.argmin(costs))
    best_thr[n], val_cost[n] = float(THR[k]), int(costs[k])
    print(n, "costs:", dict(zip(THR.tolist(), costs)))
    print(f"  -> cheapest threshold {best_thr[n]}  validation cost INR {val_cost[n]:,}")

selected = min(val_cost, key=val_cost.get)
print("\nselected model (lowest validation cost):", selected)

# ---------------------------------------------------------------- single test evaluation
print("\n--- test evaluation (first and only use of test set)")
no_action, offer_all = COST_MISS * int(y_test.sum()), COST_OFFER * int((y_test == 0).sum())
print(f"no action INR {no_action:,} | offer everybody INR {offer_all:,}")
test_res = {}
for n, m in models.items():
    pt = m.predict_proba(X_test[FEATURES])[:, 1]
    pred = (pt >= best_thr[n]).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, pred, labels=[0, 1]).ravel()
    res = dict(TN=int(tn), FP=int(fp), FN=int(fn), TP=int(tp), precision=precision_score(y_test, pred),
               recall=recall_score(y_test, pred), F1=f1_score(y_test, pred), cost=int(cost(y_test, pred)))
    test_res[n] = res
    print(n, "thr", best_thr[n], {k: (round(v, 3) if isinstance(v, float) else v) for k, v in res.items()})
sel = test_res[selected]
print(f"bars -> cost {sel['cost']:,} <= {int(0.6 * no_action):,}: {sel['cost'] <= 0.6 * no_action} | "
      f"recall {sel['recall']:.3f} >= 0.55: {sel['recall'] >= 0.55} | F1 {sel['F1']:.3f} >= 0.50: {sel['F1'] >= 0.5}")

# ---------------------------------------------------------------- explain
print("\n--- explanation")
names = gs_rf.best_estimator_.named_steps["pre"].get_feature_names_out()
imp = pd.Series(gs_rf.best_estimator_.named_steps["model"].feature_importances_, index=names).sort_values(ascending=False)
print("top-5 RF importances:\n", imp.head(5).round(3).to_string())
lr_names = gs_lr.best_estimator_.named_steps["pre"].get_feature_names_out()
coef = pd.Series(gs_lr.best_estimator_.named_steps["model"].coef_[0], index=lr_names)
for f in ["num__support_calls_90d", "num__tenure_months", "num__n_failed_6m", "num__recency_days", "num__hours_watched_per_week"]:
    print(f"LR coef {f}: {coef[f]:+.3f}")

# ---------------------------------------------------------------- persist and verify
final = models[selected]
joblib.dump(final, "outputs/churn_model.joblib")
json.dump({"selected": selected, "threshold": best_thr[selected]}, open("outputs/churn_model_meta.json", "w"))
reloaded = joblib.load("outputs/churn_model.joblib")
same = np.array_equal(final.predict_proba(X_test[FEATURES]), reloaded.predict_proba(X_test[FEATURES]))
same_lab = np.array_equal(final.predict(X_test[FEATURES]), reloaded.predict(X_test[FEATURES]))
print("\nreloaded model reproduces test probabilities exactly:", same, "| predictions:", same_lab)
out = pd.DataFrame({"subscriber_id": X_test.subscriber_id.values,
                    "churn_probability": final.predict_proba(X_test[FEATURES])[:, 1],
                    "churned": y_test.values})
out.to_csv("outputs/test_scores.csv", index=False)
print("test_scores.csv rows:", len(out))
