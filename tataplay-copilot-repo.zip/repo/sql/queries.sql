-- Q1 revenue by plan (successful recharges only)
SELECT p.plan_name,
       SUM(r.amount_inr)              AS revenue,
       ROUND(AVG(r.amount_inr), 2)    AS avg_amount,
       COUNT(DISTINCT r.subscriber_id) AS subscribers
FROM recharges r
INNER JOIN subscribers s ON s.subscriber_id = r.subscriber_id
INNER JOIN plans p       ON p.plan_id = s.plan_id
WHERE r.status = 'success'
GROUP BY p.plan_name
ORDER BY revenue DESC;

-- Q2 subscribers who never successfully recharged
SELECT s.subscriber_id, s.tenure_months, s.plan_id
FROM subscribers s
LEFT JOIN (SELECT recharge_id, subscriber_id FROM recharges WHERE status = 'success') r
       ON r.subscriber_id = s.subscriber_id
WHERE r.recharge_id IS NULL;

-- Q3 ranking within a city
WITH totals AS (
  SELECT s.subscriber_id, s.city, SUM(r.amount_inr) AS total
  FROM subscribers s
  JOIN recharges r ON r.subscriber_id = s.subscriber_id AND r.status = 'success'
  GROUP BY s.subscriber_id, s.city
)
SELECT subscriber_id, city, total,
       RANK()       OVER (PARTITION BY city ORDER BY total DESC) AS rnk,
       DENSE_RANK() OVER (PARTITION BY city ORDER BY total DESC) AS dense_rnk,
       ROW_NUMBER() OVER (PARTITION BY city ORDER BY total DESC, subscriber_id) AS row_num
FROM totals
ORDER BY city, row_num;

-- Q4 running total for TP00010
SELECT recharge_id, recharge_date, amount_inr,
       SUM(amount_inr) OVER (ORDER BY recharge_date, recharge_id) AS running_total
FROM recharges
WHERE subscriber_id = 'TP00010' AND status = 'success'
ORDER BY recharge_date, recharge_id;
