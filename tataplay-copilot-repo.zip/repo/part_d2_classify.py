"""Part D task 2: weak, zero-shot and few-shot ticket classification with LangChain pipes."""
import mock_llm
import pandas as pd
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

import llm_client as C

LABELS = ["billing", "signal", "plan_change", "cancellation"]
tk = pd.read_csv("data/raw/tickets.csv")
tk = tk[tk.text.str.strip() != "..."].reset_index(drop=True)
shots = pd.read_csv("data/raw/few_shot_examples.csv")
print("readable tickets:", len(tk))

WEAK = "TICKET CLASSIFIER. Classify the ticket."
STRONG = ("TICKET CLASSIFIER. You are a support-desk assistant for a satellite TV and broadband provider. "
          "Classify the customer ticket into exactly one of these labels: billing, signal, plan_change, cancellation. "
          "Respond with only the label, in lower case, and nothing else. Do not create new labels.")
FEW = STRONG + "\n\nExamples:\n" + "\n\n".join(f"Ticket: {r.text}\nLabel: {r.label}" for r in shots.itertuples())


def run(system_text, name):
    """Classify every readable ticket with one system prompt; return outputs and recovered rate limits."""
    mock_llm.reset()
    C.stats["recovered_429"] = 0
    prompt = ChatPromptTemplate.from_messages([("system", "{system_text}"), ("human", "{ticket}")])
    chain = prompt | C.llm_fn | StrOutputParser()
    outs = [chain.invoke({"system_text": system_text, "ticket": t}).strip() for t in tk.text]
    valid = sum(o in LABELS for o in outs)
    correct = sum(o == t for o, t in zip(outs, tk.true_category))
    print(f"{name}: valid {valid}/{len(outs)} | correct {correct} ({correct / len(outs) * 100:.2f}%) | "
          f"rate limits recovered {C.stats['recovered_429']}")
    return outs


weak, zero, few = run(WEAK, "weak"), run(STRONG, "zero-shot"), run(FEW, "few-shot")
out = pd.DataFrame({"ticket_id": tk.ticket_id, "true_category": tk.true_category, "zero_shot": zero, "few_shot": few})
out.to_csv("outputs/ticket_classification.csv", index=False)
print("\nfew-shot mistakes:")
for i in out.index[out.few_shot != out.true_category]:
    print(f"  {tk.ticket_id[i]} true={tk.true_category[i]} predicted={few[i]} | {tk.text[i]}")
