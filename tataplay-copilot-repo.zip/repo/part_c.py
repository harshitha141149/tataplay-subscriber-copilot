"""Part C: K-means segments, correlated-feature spend model (OLS/Ridge/Lasso), revenue at risk."""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.linear_model import Lasso, LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, silhouette_score
from sklearn.model_selection import GridSearchCV, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

subs = pd.read_csv("data/clean/subscribers.csv")

# ---------------------------------------------------------------- 1. K-means
cols = ["tenure_months", "hours_watched_per_week", "monthly_recharge_inr"]
scaler = StandardScaler().fit(subs[cols])
Z = scaler.transform(subs[cols])
print("K | inertia | silhouette")
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(Z)
    print(f"{k} | {km.inertia_:.1f} | {silhouette_score(Z, km.labels_):.3f}")

K = 4
km = KMeans(n_clusters=K, n_init=10, random_state=42).fit(Z)
subs["segment_id"] = km.labels_
prof = subs.groupby("segment_id").agg(size=("subscriber_id", "size"), mean_tenure=("tenure_months", "mean"),
                                      mean_hours=("hours_watched_per_week", "mean"),
                                      mean_recharge=("monthly_recharge_inr", "mean"), churn_rate=("churned", "mean"))
print("\n--- profile K=4\n", prof.round(3).to_string())

premium = prof.mean_recharge.idxmax()
at_risk = prof.churn_rate.idxmax()
names = {premium: "Premium", at_risk: "At-Risk"}
rest = [i for i in prof.index if i not in names]
rest_sorted = sorted(rest, key=lambda i: prof.loc[i, "mean_hours"], reverse=True)
names[rest_sorted[0]] = "Engaged Families"
names[rest_sorted[1]] = "Steady Budget"
subs["segment_name"] = subs.segment_id.map(names)
prof["segment_name"] = prof.index.map(names)
print(prof[["segment_name", "size"]].to_string())
subs[["subscriber_id", "segment_id", "segment_name"]].to_csv("outputs/segments.csv", index=False)

new = pd.DataFrame([[4, 15, 520]], columns=cols)
zn = scaler.transform(new)[0]
d = np.sqrt(((km.cluster_centers_ - zn) ** 2).sum(axis=1))
print("\nnew subscriber scaled:", zn.round(3), "| distances:", d.round(3), "| nearest:", int(d.argmin()),
      names[int(d.argmin())], "| kmeans.predict:", int(km.predict(zn.reshape(1, -1))[0]))

# ---------------------------------------------------------------- 2. collinearity
beh = ["hours_watched_per_week", "hd_hours_per_week", "sports_hours_per_week", "channels_watched"]
C = subs[beh].corr()
print("\n--- correlation\n", C.round(3).to_string())
for i in range(4):
    for j in range(i + 1, 4):
        if abs(C.iloc[i, j]) > 0.9:
            print(f"|r|>0.9: {beh[i]} - {beh[j]}: {C.iloc[i, j]:.3f}")

# ---------------------------------------------------------------- 3. spend model
feat = ["monthly_recharge_inr", "tenure_months", "hours_watched_per_week", "hd_hours_per_week",
        "sports_hours_per_week", "channels_watched", "support_calls_90d"]
stay = subs[subs.churned == 0]
Xtr, Xte, ytr, yte = train_test_split(stay[feat], stay.next_cycle_recharge_inr, test_size=0.2, random_state=42)
print("\nspend model rows: train", len(Xtr), "test", len(Xte))
alphas = [0.001, 0.01, 0.1, 0.5, 1, 2, 3, 10, 30, 100]
fits = {"LinearRegression": Pipeline([("sc", StandardScaler()), ("m", LinearRegression())]).fit(Xtr, ytr)}
cvr2 = {"LinearRegression": cross_val_score(fits["LinearRegression"], Xtr, ytr, cv=5, scoring="r2").mean()}
best_alpha = {}
for n, est in (("Ridge", Ridge()), ("Lasso", Lasso(max_iter=10000))):
    g = GridSearchCV(Pipeline([("sc", StandardScaler()), ("m", est)]), {"m__alpha": alphas}, cv=5, scoring="r2").fit(Xtr, ytr)
    fits[n], cvr2[n], best_alpha[n] = g.best_estimator_, g.best_score_, g.best_params_["m__alpha"]
print("model | best alpha | CV R2 | test R2 | MAE | RMSE")
for n, m in fits.items():
    p = m.predict(Xte)
    print(f"{n} | {best_alpha.get(n, '-')} | {cvr2[n]:.4f} | {r2_score(yte, p):.4f} | "
          f"{mean_absolute_error(yte, p):.2f} | {np.sqrt(mean_squared_error(yte, p)):.2f}")
coef = pd.DataFrame({n: m.named_steps["m"].coef_ for n, m in fits.items()}, index=feat)
print("\ncoefficients (standardised features)\n", coef.round(3).to_string())
print("Lasso exact zeros:", [f for f in feat if fits["Lasso"].named_steps["m"].coef_[feat.index(f)] == 0])

j = feat.index("hours_watched_per_week")
lin_c, rid_c = [], []
for k in range(5):
    sub = Xtr.sample(frac=0.8, random_state=k)
    ys = ytr.loc[sub.index]
    lin_c.append(Pipeline([("sc", StandardScaler()), ("m", LinearRegression())]).fit(sub, ys).named_steps["m"].coef_[j])
    rid_c.append(Pipeline([("sc", StandardScaler()), ("m", Ridge(alpha=30))]).fit(sub, ys).named_steps["m"].coef_[j])
print(f"\nstability of hours coefficient (np.std ddof=0): LinearRegression {np.std(lin_c):.3f} | Ridge(30) {np.std(rid_c):.3f}")
print(f"  (ddof=1: {np.std(lin_c, ddof=1):.3f} vs {np.std(rid_c, ddof=1):.3f})")

# ---------------------------------------------------------------- 4. revenue at risk
scores = pd.read_csv("outputs/test_scores.csv")
t = scores.merge(subs, on="subscriber_id", suffixes=("", "_s"))
t["predicted_next_recharge_inr"] = fits["Ridge"].predict(t[feat])
t["revenue_at_risk_inr"] = t.churn_probability * t.predicted_next_recharge_inr
top = t.sort_values("revenue_at_risk_inr", ascending=False).head(15)
top[["subscriber_id", "churn_probability", "predicted_next_recharge_inr", "revenue_at_risk_inr",
     "segment_name", "churned"]].to_csv("outputs/retention_priority.csv", index=False)
print("\n--- top 15 revenue at risk\n", top[["subscriber_id", "churn_probability", "predicted_next_recharge_inr",
                                              "revenue_at_risk_inr", "segment_name", "churned"]].round(3).to_string(index=False))
print("sum revenue at risk:", round(top.revenue_at_risk_inr.sum(), 2), "| actually churned:", int(top.churned.sum()), "of 15")
