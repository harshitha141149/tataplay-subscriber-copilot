"""Retrieval-augmented policy assistant: chunking, Chroma store, retrieval and grounded answering."""
import glob
import hashlib
import os
import re

import chromadb
from chromadb.utils import embedding_functions

import llm_client as C

POLICY_DIR = "data/policies"
FALLBACK = "I don't have enough information to answer that."
GROUNDED_SYSTEM = ("POLICY ASSISTANT. Answer the question using only the context below. "
                   "If the context does not contain the answer, say you do not have enough information.")
UNGROUNDED_SYSTEM = "POLICY ASSISTANT. Answer the question."
_counter = {"n": 0}


def chunk_text(text, size=400, overlap=60):
    """Split text into chunks of `size` characters starting every size-overlap characters.

    A start position is used only while start + overlap < len(text), so the last chunk is never
    made only of text already covered by the previous chunk.
    """
    chunks, start, step = [], 0, size - overlap
    while start + overlap < len(text):
        chunks.append(text[start:start + size])
        start += step
    return chunks


def get_embedder():
    """Return the embedding function.

    EMBEDDER=st (default): SentenceTransformerEmbeddingFunction("all-MiniLM-L6-v2"), falling back to
    Chroma's ONNXMiniLM_L6_V2 if sentence-transformers/PyTorch is unavailable. EMBEDDER=onnx forces ONNX.
    EMBEDDER=smoke is an offline hashing stand-in used ONLY to smoke-test the code without a download.
    """
    mode = os.environ.get("EMBEDDER", "st").lower()
    if mode == "smoke":
        return _smoke_embedder()
    if mode == "st":
        try:
            ef = embedding_functions.SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")
            get_embedder.used = "SentenceTransformerEmbeddingFunction(all-MiniLM-L6-v2)"
            return ef
        except Exception as e:  # torch / sentence-transformers missing
            print("sentence-transformers unavailable (", type(e).__name__, ") -> using Chroma ONNXMiniLM_L6_V2")
    get_embedder.used = "ONNXMiniLM_L6_V2"
    return embedding_functions.ONNXMiniLM_L6_V2()


def _smoke_embedder():
    """Offline hashing bag-of-stems embedder (testing only; NOT the model used for reported numbers)."""
    from chromadb import EmbeddingFunction

    class Smoke(EmbeddingFunction):
        """Deterministic 256-d hashing embedder."""
        def __init__(self):
            pass

        def __call__(self, input):
            out = []
            for t in input:
                v = [0.0] * 256
                for w in re.findall(r"[a-z]+", t.lower()):
                    if w not in __import__("mock_llm").STOP:
                        v[int(hashlib.md5(w[:5].encode()).hexdigest(), 16) % 256] += 1.0
                n = sum(x * x for x in v) ** 0.5 or 1.0
                out.append([x / n for x in v])
            return out

        @staticmethod
        def name():
            return "smoke"

        def get_config(self):
            return {}

        @classmethod
        def build_from_config(cls, config):
            return cls()

    get_embedder.used = "SMOKE TEST EMBEDDER (not the real model)"
    return Smoke()


def load_policies():
    """Return {file name: text} for the five policy files."""
    return {os.path.basename(p): open(p).read() for p in sorted(glob.glob(f"{POLICY_DIR}/*.txt"))}


def build_collection(size=400, overlap=60, ef=None):
    """Chunk all policy files and store them in a fresh in-memory Chroma collection with cosine distance."""
    ef = ef or get_embedder()
    client = chromadb.Client()
    _counter["n"] += 1
    col = client.create_collection(f"policies_{size}_{overlap}_{_counter['n']}", embedding_function=ef,
                                   configuration={"hnsw": {"space": "cosine"}})
    ids, docs, metas = [], [], []
    for fname, text in load_policies().items():
        for i, ch in enumerate(chunk_text(text, size, overlap)):
            ids.append(f"{fname}::{i}")
            docs.append(ch)
            metas.append({"source": fname, "chunk": i})
    col.add(ids=ids, documents=docs, metadatas=metas)
    return col


def retrieve(query, k=3, col=None):
    """Top-k chunks for a query as dicts with source, similarity (1 - cosine distance) and text."""
    r = col.query(query_texts=[query], n_results=k)
    return [{"source": m["source"], "similarity": 1 - d, "text": t}
            for m, d, t in zip(r["metadatas"][0], r["distances"][0], r["documents"][0])]


def context_block(hits):
    """Format retrieved chunks as '[file]\\ntext' blocks separated by blank lines."""
    return "\n\n".join(f"[{h['source']}]\n{h['text']}" for h in hits)


def answer(question, col, threshold, grounded=True):
    """Answer a policy question. Grounded mode rejects low-similarity questions without calling the model."""
    hits = retrieve(question, 3, col)
    if grounded and hits[0]["similarity"] < threshold:
        return FALLBACK, hits
    system = GROUNDED_SYSTEM if grounded else UNGROUNDED_SYSTEM
    user = f"CONTEXT:\n{context_block(hits)}\nQUESTION:\n{question}"
    text = C.call_llm([{"role": "system", "content": system}, {"role": "user", "content": user}])
    return text, hits
