"""Shared feature definitions used by Part B (training) and copilot.py (re-scoring)."""
import numpy as np
import pandas as pd

SNAP = pd.Timestamp("2026-03-31")
NUM = ["tenure_months", "age", "add_on_count", "monthly_recharge_inr", "hours_watched_per_week",
       "hd_hours_per_week", "sports_hours_per_week", "channels_watched", "support_calls_90d",
       "n_success_6m", "n_failed_6m", "recency_days"]
CAT = ["city", "plan_id", "payment_mode", "auto_renew"]
FEATURES = NUM + CAT
LEAKY = ["closure_request_logged", "next_cycle_recharge_inr"]


def recharge_features(recharges: pd.DataFrame) -> pd.DataFrame:
    """Per-subscriber n_success_6m, n_failed_6m and recency_days as of 2026-03-31.

    recharges needs columns subscriber_id, recharge_date, status (lower-case). Subscribers without
    any successful recharge get NaN recency; subscribers absent from the result are given 0 counts
    by add_recharge_features.
    """
    r = recharges.copy()
    r["recharge_date"] = pd.to_datetime(r["recharge_date"])
    r = r[r.recharge_date <= SNAP]
    g = r.groupby("subscriber_id")
    out = pd.DataFrame({
        "n_success_6m": g.status.apply(lambda x: int((x == "success").sum())),
        "n_failed_6m": g.status.apply(lambda x: int((x == "failed").sum())),
    })
    last = r[r.status == "success"].groupby("subscriber_id").recharge_date.max()
    out["recency_days"] = (SNAP - last).dt.days
    return out


def add_recharge_features(subs: pd.DataFrame, recharges: pd.DataFrame) -> pd.DataFrame:
    """Left-join the three recharge features onto subscribers; counts default to 0, recency stays missing."""
    f = recharge_features(recharges)
    df = subs.merge(f, left_on="subscriber_id", right_index=True, how="left")
    df[["n_success_6m", "n_failed_6m"]] = df[["n_success_6m", "n_failed_6m"]].fillna(0).astype(int)
    return df


def build_feature_row(subscriber_id: str, con) -> pd.DataFrame:
    """Full one-row feature frame for one subscriber, read from the SQLite database with SQL.

    Missing values (age, payment_mode, recency) are converted from None to NaN so the fitted
    pipeline treats them exactly as in training.
    """
    s = pd.read_sql_query("SELECT * FROM subscribers WHERE subscriber_id = ?", con, params=(subscriber_id,))
    r = pd.read_sql_query(
        "SELECT subscriber_id, recharge_date, status FROM recharges WHERE subscriber_id = ?", con, params=(subscriber_id,))
    df = add_recharge_features(s, r)
    df = df.replace({None: np.nan})
    return df
