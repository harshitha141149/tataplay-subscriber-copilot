"""Part D task 3: validated structured extraction with retry and graceful failure."""
import json
from typing import Literal, Optional

import mock_llm
import pandas as pd
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field, ValidationError

import llm_client as C
from validated import invoke_with_retry


class TicketRecord(BaseModel):
    """Structured fields extracted from one support ticket."""
    subscriber_id: Optional[str] = None
    category: Literal["billing", "signal", "plan_change", "cancellation", "other"]
    urgency: int = Field(ge=1, le=5)
    wants_refund: bool


print("--- what Pydantic does")
print("urgency '3' ->", repr(TicketRecord(category="billing", urgency="3", wants_refund=False).urgency))
for label, kw in (("urgency=9", dict(category="billing", urgency=9, wants_refund=False)),
                  ("category='refund'", dict(category="refund", urgency=3, wants_refund=False))):
    try:
        TicketRecord(**kw)
    except ValidationError as e:
        d = e.errors()[0]
        print(f"{label} -> field {d['loc'][0]!r}, error type {d['type']!r}")

parser = PydanticOutputParser(pydantic_object=TicketRecord)
prompt = ChatPromptTemplate.from_messages([
    ("system", "TICKET EXTRACTOR. Extract subscriber_id, category, urgency (1-5) and wants_refund from the support ticket. "
               "Reply with one JSON object only.\n{format_instructions}"),
    ("human", "{ticket}")]).partial(format_instructions=parser.get_format_instructions())

tk = pd.read_csv("data/raw/tickets.csv")
mock_llm.reset()
C.stats["recovered_429"] = 0
rows, first_fail = [], []
for t in tk.itertuples():
    rec, attempts, err = invoke_with_retry(prompt, {"ticket": t.text}, parser, max_retries=2)
    if err is not None:
        kind = "not_json" if "Invalid json output" in str(err) else "schema"
        first_fail.append((t.ticket_id, kind, t.text, str(err)))
    rows.append({"ticket_id": t.ticket_id, "status": "valid" if rec else "manual_review", "attempts": attempts,
                 "record": json.loads(rec.model_dump_json()) if rec else None})
with open("outputs/ticket_extractions.jsonl", "w") as f:
    for r in rows:
        f.write(json.dumps(r) + "\n")

valid = [r for r in rows if r["status"] == "valid"]
print("\n--- outcomes")
print("valid on first attempt:", sum(r["status"] == "valid" and r["attempts"] == 1 for r in rows))
print("valid after one retry:", sum(r["status"] == "valid" and r["attempts"] == 2 for r in rows))
print("valid after two retries:", sum(r["status"] == "valid" and r["attempts"] == 3 for r in rows))
print("manual_review:", sum(r["status"] == "manual_review" for r in rows))
print("first-attempt failures:", len(first_fail), "| not JSON:", sum(k == "not_json" for _, k, _, _ in first_fail),
      "(unreadable '...' tickets:", sum(x == "..." for _, _, x, _ in first_fail), ", chatty prose:",
      sum(k == "not_json" and x != "..." for _, k, x, _ in first_fail), ") | schema:", sum(k == "schema" for _, k, _, _ in first_fail))
sch = [r for r in first_fail if r[1] == "schema"]
def _field(msg):
    """Name of the field reported by Pydantic (the line after 'validation error for TicketRecord')."""
    return msg.split("validation error for TicketRecord")[-1].strip().splitlines()[0].strip()


print("   schema breaks: urgency out of range:", sum(_field(r[3]) == "urgency" for r in sch),
      "| category outside list:", sum(_field(r[3]) == "category" for r in sch))
print("rate limits recovered:", C.stats["recovered_429"])
print("valid records with wants_refund true:", sum(r["record"]["wants_refund"] for r in valid),
      "| null subscriber_id:", sum(r["record"]["subscriber_id"] is None for r in valid), "| total valid:", len(valid))
