"""Reliable chat-completion client. Defaults to the offline mock; LLM_MODE=live switches to a real endpoint."""
import os
import time

import mock_llm

MODEL = "openai/gpt-4o-mini"
BASE_DELAY = 0.05
MAX_RETRIES = 3
LIVE_URL = "https://openrouter.ai/api/v1/chat/completions"

stats = {"recovered_429": 0, "length_truncations": 0}
last_call = {"finish_reason": None, "retries": 0}


class LLMError(RuntimeError):
    """Raised for non-retryable API errors (400, 401, 404) and for exhausted retries."""


def _post(headers, payload):
    """Send one request to the mock (default) or, when LLM_MODE=live, to the real endpoint with requests."""
    if os.environ.get("LLM_MODE", "mock").lower() == "live":
        import requests  # only needed in live mode
        return requests.post(LIVE_URL, headers=headers, json=payload, timeout=60)
    return mock_llm.post(mock_llm.URL, headers=headers, json=payload)


def call_llm(messages, temperature=0.0, max_tokens=300):
    """Call the chat API and return the reply text.

    Builds the headers and payload, retries only on HTTP 429 (at most 3 retries, waiting
    BASE_DELAY * 2**n seconds before retry n), raises LLMError at once for 400/401/404, and
    records finish_reason in last_call (a note is printed when it is "length").
    """
    key = os.environ.get("OPENROUTER_API_KEY", "") if os.environ.get("LLM_MODE", "mock").lower() == "live" else "mock-key"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {"model": MODEL, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
    retries = 0
    while True:
        resp = _post(headers, payload)
        if resp.status_code == 200:
            choice = resp.json()["choices"][0]
            last_call.update(finish_reason=choice["finish_reason"], retries=retries)
            if retries:
                stats["recovered_429"] += 1
            if choice["finish_reason"] == "length":
                stats["length_truncations"] += 1
                print("note: reply truncated (finish_reason='length'); raise max_tokens if the text is incomplete")
            return choice["message"]["content"]
        if resp.status_code == 429:
            if retries >= MAX_RETRIES:
                raise LLMError("rate limited: gave up after 3 retries")
            time.sleep(BASE_DELAY * 2 ** retries)
            retries += 1
            continue
        if resp.status_code in (400, 401, 404):
            raise LLMError(f"HTTP {resp.status_code}: {resp.json().get('error', {}).get('message', 'error')}")
        raise LLMError(f"unexpected HTTP {resp.status_code}")


def lc_to_dicts(prompt_value):
    """Convert a LangChain prompt value into the role/content dictionaries the API expects."""
    role = {"system": "system", "human": "user", "ai": "assistant"}
    return [{"role": role[m.type], "content": m.content} for m in prompt_value.to_messages()]


def llm_fn(prompt_value, max_tokens=300):
    """Plain function used inside LangChain pipes: prompt value in, reply text out."""
    return call_llm(lc_to_dicts(prompt_value), max_tokens=max_tokens)
