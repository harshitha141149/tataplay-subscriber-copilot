# Tata Play Subscriber Retention & Support Copilot

## Overview

An internal tool built in four connected Parts on **synthetic, fictional data** (the brand name only frames the scenario; all amounts are INR).

| Part | What it does | Main files |
|---|---|---|
| A | Audit, clean and store the raw exports in SQLite; four SQL queries | `part_a.py`, `sql/queries.sql` |
| B | Churn model with a leakage check, tuning and a cost-based alert threshold | `part_b.py`, `features.py` |
| C | K-means segments, Ridge/Lasso spend model, ranked revenue at risk | `part_c.py` |
| D | LLM client, ticket classifier, validated extraction, RAG policy assistant, retention-brief writer | `llm_client.py`, `part_d*.py`, `rag.py`, `validated.py`, `copilot.py` |

`generate_data.py` and `mock_llm.py` are the supplied files, committed unmodified. Every language-model call goes through the offline `mock_llm.py`; no key, account or network is needed for it.

**Versions used:** Python 3.12.3, pandas 3.1.1, numpy 2.5.5, scikit-learn 1.9.1, pydantic 2.14.4, langchain-core 1.8.5, chromadb 1.5.9, joblib 1.6.0 (all pinned in `requirements.txt`). `sentence-transformers` (PyTorch) is *not* in `requirements.txt`; see Part D task 4.

## Reproduce

```bash
# 1. environment
python -m venv .venv
# 2. activate it (Windows: .venv\Scripts\activate)
source .venv/bin/activate
# 3. install pinned libraries
pip install -r requirements.txt
# 4. (recommended, ~GBs because of PyTorch) the sentence-transformers embedder used in Part D task 4
pip install sentence-transformers
# 5. generate the synthetic data (last line must be: generated: subscribers=2415 recharges_raw=13055 tickets=150 policy_files=5)
python generate_data.py
# 6. Part A  -> data/clean/*.csv, data/tataplay.db
python part_a.py
# 7. Part B  -> outputs/churn_model.joblib, outputs/test_scores.csv
python part_b.py
# 8. Part C  -> outputs/segments.csv, outputs/retention_priority.csv
python part_c.py
# 9. Part D tasks 1-3 -> outputs/ticket_classification.csv, outputs/ticket_extractions.jsonl
python part_d1_client.py
python part_d2_classify.py
python part_d3_extract.py
# 10. Part D task 4 (downloads the ~90 MB embedding model once) -> outputs/rag_eval.csv
python part_d4_rag.py
# 11. Part D task 5 -> outputs/retention_briefs.jsonl
python copilot.py
```

`./run_all.sh` runs steps 5-11 and saves each console output under `logs/`. Scripts must run in this order because each Part reads the previous Part's files.

---

## Part A

**Rules applied.** No missing value was filled in Part A. Imputation belongs inside the Part B pipeline, fitted on training rows only, so that no test row can influence it.

### Audit of the raw tables

| Table | Shape | Missing values |
|---|---|---|
| subscribers.csv | 2,415 × 17 | age 99 (4.10%), payment_mode 116 (4.80%), next_cycle_recharge_inr 516 (21.37%); all other columns 0 |
| recharges.csv | 13,055 × 6 | none |

Dtypes: numeric columns are int64/float64 (age and next_cycle_recharge_inr are float because of blanks); all identifier and text columns are strings, including recharges' `amount_inr` and `recharge_date`.

| Figure | Value |
|---|---|
| subscribers rows / exact duplicate rows / distinct subscriber_id | 2,415 / 15 / 2,400 |
| blank age / age outside 10-100 / blank payment_mode | 99 / 6 / 116 |
| distinct raw city spellings / raw auto_renew spellings / blank next_cycle_recharge_inr | 22 / 6 / 516 |
| recharges rows / exact duplicate rows / distinct recharge_id | 13,055 / 60 / 12,995 |
| amount_inr that is not a plain number / raw status spellings / orphan subscriber_id rows | 366 / 6 / 10 |

### Cleaning rules and what each changed

| Rule | Changed |
|---|---|
| subscribers: drop exact duplicate rows | 15 rows (2,415 → 2,400) |
| city: trim, ignore case, map Bangalore→Bengaluru, Bombay→Mumbai, Madras→Chennai, Calcutta→Kolkata, New Delhi→Delhi, Hyd→Hyderabad | 22 raw spellings → 7 cities |
| auto_renew: Y/yes/Yes → Yes, N/no/No → No | 6 spellings → 2 |
| age outside 10-100 → missing | 6 values (99 + 6 = 104 missing) |
| recharges: drop exact duplicate rows | 60 rows |
| recharges: drop rows whose subscriber does not exist | 10 rows (13,055 → 12,985) |
| status: lower-case | 6 spellings → 3 |
| amount_inr: convert to number; text such as `INR 498` rebuilt as the subscriber's monthly_recharge_inr | 364 values rebuilt |
| recharge_date: parsed as a date | all rows |

Cleaned results: cities Mumbai 524, Delhi 436, Chennai 391, Bengaluru 386, Hyderabad 262, Pune 245, Kolkata 156; auto_renew No 1,355 / Yes 1,045; 104 missing age and 114 missing payment_mode remain; 514 churned (21.42%). Recharge status: success 11,442, failed 1,422, pending 121; total successful amount INR 6,457,573. Files: `data/clean/subscribers.csv`, `recharges.csv`, `plans.csv` (copied unchanged) and `data/tataplay.db`.

### SQL results (`sql/queries.sql`, successful recharges only)

**Q1 revenue by plan** (INNER JOIN recharges, subscribers, plans):

| plan_name | SUM | AVG | distinct subscribers |
|---|---|---|---|
| Premium | 1,471,199 | 860.35 | 339 |
| Standard | 1,323,622 | 492.60 | 559 |
| Standard HD | 1,283,471 | 645.61 | 407 |
| Premium Plus | 1,262,398 | 1,075.30 | 228 |
| Basic | 782,554 | 326.61 | 493 |
| Basic Lite | 334,329 | 224.83 | 298 |

Confirmed with a pandas groupby (Premium: sum 1,471,199, mean 860.35, 339 subscribers).

**Q2 never successfully recharged** (LEFT JOIN … WHERE key IS NULL): **76 subscribers, 68 with tenure_months = 0.** An INNER JOIN keeps only subscribers that have at least one matching successful recharge, so these 76 would simply have no row and vanish without any warning. A report built on it would then overstate the healthy share of the base and hide exactly the group (new joiners, plus failed payers) that retention cares about.

**Q3 ranking within a city.** Subscribers with RANK() = 1: Bengaluru 10, Chennai 10, Delhi 5, Hyderabad 5, Kolkata 2, Mumbai 6, Pune 4; ROW_NUMBER() = 1 is exactly 1 per city.

| Kolkata | total | RANK | DENSE_RANK | ROW_NUMBER |
|---|---|---|---|---|
| TP00074 | 6,876 | 1 | 1 | 1 |
| TP00917 | 6,876 | 1 | 1 | 2 |
| TP00143 | 6,582 | 3 | 2 | 3 |
| TP01355 | 6,582 | 3 | 2 | 4 |

For "the top spender per city" I would use ROW_NUMBER() = 1, because it returns exactly one subscriber per city, whereas RANK() and DENSE_RANK() return every tied subscriber (10 rows for Bengaluru, 2 for Kolkata).

**Q4 running total, TP00010:** 5 rows (498 each, 2025-10-15 … 2026-03-13); the running total ends at **2,490**.

---

## Part B

### 1. Framing

| Question | Answer |
|---|---|
| Decision driven | Which subscribers get a retention offer before April 2026 |
| Who acts / what changes | The retention desk calls or offers deals to flagged subscribers instead of treating everyone alike or waiting for a closure request |
| Target column | `churned` (1 = cancelled in April 2026) |
| Target type | A category (binary classification) |
| Cost of a wrong prediction | Missed churner: INR 1,200. Needless offer: INR 300 |

Class balance: **514 of 2,400 churned (21.42%).**

### 2. Modelling table, split, leakage

`features.py` builds `n_success_6m`, `n_failed_6m` and `recency_days` from the clean recharges as of 2026-03-31 (subscribers without recharge rows get 0 counts; recency stays missing: **76 subscribers**). 12 numeric + 4 categorical features.

Split (`random_state=42`, stratified): **train 1,440 / validation 480 / test 480** with **308 / 103 / 103** churners. The training set fits models and preprocessing; the validation set compares models and chooses the alert threshold; the test set is touched only once, after every choice is final.

**Leakage.** `closure_request_logged` (recorded while the subscriber is leaving, in the label window) and `next_cycle_recharge_inr` (known only after the next cycle, blank when the subscriber left) do not exist at prediction time and are excluded from every model.

| Random forest (100 trees), validation | Accuracy | Churn F1 |
|---|---|---|
| with the two leaky columns | 0.983 | 0.961 |
| without | 0.823 | 0.514 |

The leaky model reads the answer out of columns that are written only because the subscriber is already leaving, so its score measures nothing about prediction. Deployed in March it would see neither column and would fall to the honest ~0.51 F1.

### 3. Preprocessing (fit on training rows only)

One `ColumnTransformer`: numeric = median imputer + StandardScaler; categorical = most-frequent imputer + OneHotEncoder(handle_unknown="ignore"). Output columns: **31**; learned median age: **38.0**; scaler mean tenure **22.65** (train) vs **22.46** (full data); **0 missing values** remain after the transform (asserted by `np.isnan(...).sum()`). The two means differ because the scaler only sees the 1,440 training rows, which are a random subset of the 2,400.

### 4. Baseline, simple models, overfitting (validation)

| Model | Accuracy | Precision | Recall | F1 (churn) | Train accuracy |
|---|---|---|---|---|---|
| Majority class ("stays") | 0.785 | n/a | 0 | 0.000 | n/a |
| Logistic regression | 0.833 | 0.646 | 0.495 | 0.560 | n/a |
| Unrestricted decision tree | n/a | n/a | n/a | 0.459 | 1.000 |
| Default random forest | 0.823 | n/a | n/a | 0.514 | 1.000 |

| max_depth | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| train accuracy | 0.815 | 0.832 | 0.839 | 0.844 | 0.863 | 0.883 | 0.908 | 0.924 | 0.944 | 0.957 |
| validation F1 | 0.434 | 0.413 | 0.408 | 0.422 | 0.529 | **0.545** | 0.488 | 0.489 | 0.468 | 0.440 |

The gap between training accuracy (rising) and validation F1 (peaking at depth 6, then falling) shows the tree is memorising noise rather than learning patterns that generalise. A greedy tree always takes the locally best split and keeps splitting until leaves are pure, so given enough depth it carves out single noisy rows.

### 5. Cross-validated tuning (training rows only, `StratifiedKFold(5, shuffle, 42)`, scoring F1)

| Model | Combinations | Fits | Best parameters | Best CV F1 (std) |
|---|---|---|---|---|
| Logistic regression | 5 | 25 | C = 100 | 0.507 (0.035) |
| Random forest | 45 | 225 | max_depth 8, max_features 5, n_estimators 100 | 0.439 (0.061) |

CV F1 by C: 0.01 → 0.415; 0.1 → 0.500; 1 → 0.503; 10 → 0.505; 100 → 0.507 (every C ≥ 0.1 within 0.01 of the best). Logistic regression is more consistent across folds (std 0.035 vs 0.061), which matters because a model with a small spread is likelier to behave the same on next month's unseen subscribers.

### 6. Threshold by cost, then one test evaluation

Validation cost of the cheapest threshold (0.10-0.90, step 0.05): **random forest 0.30, INR 53,100; logistic regression 0.20, INR 56,400.** The curve is flat between 0.20 and 0.40 for the forest (INR 53,100-58,800). The threshold used for each model is the cheapest one on my own validation curve.

Test set, applied once with those thresholds. Reference policies: no action INR 123,600; offer everybody INR 113,100.

| Model (threshold) | TN | FP | FN | TP | Precision | Recall | F1 | Cost (INR) |
|---|---|---|---|---|---|---|---|---|
| Random forest (0.30) | 310 | 67 | 29 | 74 | 0.525 | 0.718 | 0.607 | 54,900 |
| Logistic regression (0.20) | 275 | 102 | 17 | 86 | 0.457 | 0.835 | 0.591 | 51,000 |

**Selected: random forest**, chosen on validation cost (53,100 vs 56,400), not on the test result. The forest is slightly cheaper on validation and more accurate at flagging (precision 0.525 vs 0.457, so fewer needless offers), but logistic regression is far easier to explain to the retention desk (one signed coefficient per feature) and was the more stable across CV folds. The gap between them is small and the validation curve is flat, so the honest summary is that either is defensible; I followed the pre-declared rule (cheapest on validation). On the test set the selected model costs INR 54,900 = **44.4%** of the no-action cost (bar: ≤ 60%, INR 74,160), recall **0.718** (bar ≥ 0.55) and F1 **0.607** (bar ≥ 0.50). All three bars are met. (On the test set the logistic model happens to be a little cheaper, INR 51,000; that was not used to choose.)

### 7. Explanation, persistence, ordering

Top-5 random-forest features: `support_calls_90d` 0.196 (people who keep calling are unhappy), `recency_days` 0.091 (long since last paid), `tenure_months` 0.082 (newer subscribers leave more), `n_success_6m` 0.079 (fewer payments made), `hd_hours_per_week` 0.067 (viewing intensity).

Logistic-regression coefficients (standardised features): `support_calls_90d` **+1.075** (more calls, more churn); `tenure_months` **−0.511** (longer tenure protects); `n_failed_6m` **+0.211** (payment trouble raises risk); `recency_days` +0.273.

`outputs/churn_model.joblib` is the selected pipeline; reloading it with `joblib.load` reproduces the test probabilities and predictions exactly (checked: `True`). `outputs/test_scores.csv` has 480 rows (`subscriber_id, churn_probability, churned`); the chosen threshold is stored in `outputs/churn_model_meta.json`.

**No imputer, scaler, encoder or threshold search saw test rows.** Order of use: (1) train: fit preprocessing and every model; (2) cross-validation inside train only; (3) validation: compare models and search the threshold; (4) test: one evaluation after all choices were fixed.

---

## Part C

### 1. K-means (tenure, weekly hours, monthly recharge; standardised)

| K | Inertia | Silhouette |
|---|---|---|
| 2 | 3728.2 | 0.420 |
| 3 | 2813.0 | 0.346 |
| 4 | 2193.9 | 0.340 |
| 5 | 1781.1 | 0.343 |
| 6 | 1502.5 | 0.344 |
| 7 | 1292.8 | 0.364 |
| 8 | 1191.4 | 0.336 |

The elbow is mild but visible around K = 4 (inertia falls ~22% from 3 to 4 and ~19% from 4 to 5, with no sharp bend afterwards), and silhouettes for K = 3-6 are all ~0.34. **I chose K = 4**: it gives four business-readable groups. K = 8 always has lower inertia than K = 2 because more centroids can only reduce the distance to the nearest centre, and K = 2 has the best silhouette here because the data splits coarsely into two big blobs. Neither fact alone picks K: inertia always falls with K, and silhouette favours the coarsest split, so the choice needs interpretability too.

### 2. Segment profiles (K = 4; cluster numbers are only labels with no order)

| id | Name | Size | Mean tenure (months) | Mean hours/week | Mean monthly recharge (INR) | Churn rate | Action |
|---|---|---|---|---|---|---|---|
| 3 | **At-Risk** | 784 | 6.3 | 14.9 | 514 | 32.8% | Onboarding call in month 1-3, auto-renew setup |
| 2 | **Premium** | 480 | 34.2 | 33.6 | 942 | 10.6% | Protect: priority support, HD/box upgrades |
| 1 | Engaged Families | 543 | 34.2 | 22.2 | 560 | 13.4% | Add-on and plan-upgrade offers |
| 0 | Steady Budget | 593 | 23.6 | 7.1 | 301 | 22.4% | Low-cost loyalty nudges, watch price sensitivity |

The churn label only describes the segments; it was never used to build them.

**New subscriber** (tenure 4, 15 h/week, INR 520), by hand: scaled with the fitted scaler = (−1.206, −0.323, −0.143); Euclidean distances to the four centroids = 1.708 (id 0), 2.094 (id 1), 3.117 (id 2), **0.153 (id 3)**. Nearest: **At-Risk**, and `kmeans.predict` agrees (id 3). Written to `outputs/segments.csv` (2,400 rows).

### 3. Collinearity and the spend model

Pairs with |r| > 0.9: hours-HD 0.979, hours-sports 0.947, hours-channels 0.938, HD-sports 0.927, HD-channels 0.921 (sports-channels 0.891 is below the line).

Churned = 0 only; 1,508 train / 378 test rows; alpha grid searched with `cv=5, scoring="r2"` on train.

| Model | Best alpha | CV R² | Test R² | MAE | RMSE |
|---|---|---|---|---|---|
| LinearRegression | n/a | 0.9941 | 0.9930 | 20.16 | 24.70 |
| Ridge | 0.01 | 0.9941 | 0.9930 | 20.16 | 24.70 |
| Lasso | 0.1 | 0.9941 | 0.9930 | 20.11 | 24.65 |

**Lasso zeros:** `tenure_months`, `hours_watched_per_week`, `channels_watched`. When several features carry nearly the same information, the L1 penalty gets the same fit from fewer coefficients, so it keeps the cheapest representative (here `hd_hours` and `sports_hours`) and shrinks the redundant ones to exactly zero.

**Stability** (coefficient of `hours_watched_per_week` over five 80% subsamples, population std): LinearRegression **1.945**, Ridge(alpha=30) **0.896** (with ddof=1: 2.175 vs 1.001). With correlated features the data cannot tell which feature deserves the credit, so ordinary least-squares coefficients swing between samples (here the hours coefficient is about −5.2 on the full training set even though hours is strongly related to spend) while the predictions stay good. Individual coefficients should not be read as effects of one feature unless the features are not strongly correlated, or the model is regularised.

### 4. Revenue at risk (`outputs/retention_priority.csv`)

`revenue_at_risk_inr = churn_probability × predicted_next_recharge_inr` (Ridge predictions for all 480 test subscribers). Top 15: **sum INR 8,716.53; 12 of the 15 actually churned** (base rate 21%; bar ≥ 9). Top five: TP00798 (796.0), TP02346 (735.8), TP02228 (695.9), TP00923 (690.8), TP00986 (640.2).

This list is built from test-set subscribers whose outcome is already known, so it illustrates the method and is not a forward-looking evaluation.

---

## Part D

### 1. Client (`llm_client.py`)

`call_llm(messages, temperature=0.0, max_tokens=300)` builds the headers and payload (model `openai/gpt-4o-mini`), calls `mock_llm.post`, returns the text only on 200, retries **only** on 429 (at most 3 retries, waiting `0.05 × 2**n` s before retry n), raises `LLMError` immediately for 400/401/404 and prints a note when `finish_reason == "length"` (also stored in `llm_client.last_call`). **Live mode:** setting the environment variable `LLM_MODE=live` makes the same function use `requests.post` against `https://openrouter.ai/api/v1/chat/completions` with the key read from `OPENROUTER_API_KEY`; no key is in the code (use a git-ignored `.env`). No live call is made by any script.

| Demo (`part_d1_client.py`, `mock_llm.reset()` before each) | Result |
|---|---|
| (a) no Authorization header / wrong URL | **401** / **404** |
| (a) `call_llm` with an empty message list | raises `LLMError` (HTTP 400) after exactly 1 post, no retry |
| (b) `max_tokens=3` | finish_reason **"length"** |
| (c) "What is my name?" alone | "I do not know your name." |
| (c) with the earlier turn "My name is Asha." + assistant reply in the list | "Your name is Asha." (the model has no memory; history must be resent) |
| (d) 30 calls after a reset | **3** rate limits recovered, **33** posts in total |

### 2. Ticket classification (146 readable tickets; `LangChain: prompt | function | StrOutputParser()`)

| Prompt | Valid labels | Correct | Recovered 429s |
|---|---|---|---|
| Weak | 0 / 146 | 0 | 18 |
| Strong zero-shot | 146 / 146 | 123 (84.25%) | 18 |
| Few-shot (13 examples) | 146 / 146 | 142 (97.26%) | 18 |

Few-shot still gets four wrong: T0041 (plan_change → billing), T0094 (cancellation → signal), T0110 and T0136 (signal → cancellation). Each mentions **two intents** ("my last recharge went through fine, now I want to move to the Premium plan"; "I do not want to cancel, but there is no signal"). Fix: add few-shot examples of mixed tickets and an instruction to label by the *main request* (the thing the customer wants done), not by words that appear; or add an explicit "mentions a topic only to rule it out" rule. Chain-of-thought is worth its extra tokens when the answer needs several reasoning steps (arithmetic, multi-condition policy logic); it is not needed here because classifying a short ticket is a single-step pattern match and the label is the whole answer.

Output: `outputs/ticket_classification.csv`.

### 3. Validated extraction

Pydantic demos: `urgency="3"` is converted to the integer **3**; `urgency=9` raises `ValidationError` (field `urgency`, error type `less_than_equal`); `category="refund"` raises `ValidationError` (field `category`, error type `literal_error`).

Pipeline: `prompt | llm_fn | PydanticOutputParser(TicketRecord)`; the system message starts with TICKET EXTRACTOR and embeds `get_format_instructions()` via `partial`; the human message is exactly the ticket text. On a parse error `validated.invoke_with_retry` retries up to 2 times, appending the bad reply as an assistant message and a user message `VALIDATION ERROR: <error>`; a ticket that still fails becomes `manual_review` and the run continues.

| Outcome (150 tickets, file order) | Count |
|---|---|
| valid on first attempt | 118 |
| valid after one retry | 28 |
| valid after two retries | 0 |
| manual_review | 4 (the four `...` tickets) |
| first-attempt failures | 32 = 16 not valid JSON (12 chatty prose + 4 unreadable) + 16 schema (6 urgency 7, 10 category outside the list) |
| rate-limited responses recovered | 23 |
| among the 146 valid records: wants_refund true / null subscriber_id | 31 / 75 |

In production a `manual_review` ticket would be routed to a human queue with its ticket id and the validation errors attached (never silently dropped or guessed), and the failure rate tracked as a model-quality alarm. Output: `outputs/ticket_extractions.jsonl` (`ticket_id, status, attempts, record|null`).

### 4. Retrieval-augmented policy assistant (`rag.py`, `part_d4_rag.py`)

**(a) Chunking** (`chunk_text(size=400, overlap=60)`): **13 chunks**: cancellation 2, plan change 3, recharge and refund 3, retention offers 3, technical support 2 (verified).

**(b) Embedding.** In-memory `chromadb.Client()`, cosine distance set explicitly (`configuration={"hnsw": {"space": "cosine"}}`, similarity = 1 − distance), `all-MiniLM-L6-v2`. `rag.get_embedder()` uses `SentenceTransformerEmbeddingFunction` and, if PyTorch / sentence-transformers is not installed, falls back to Chroma's `ONNXMiniLM_L6_V2` (the same model; allowed by the brief).

> **Honest status of tasks 4(c)-(e).** The MiniLM weights have to be downloaded from the internet, and the environment in which I built and tested this repository had no access to the model host. I therefore could **not** run the real embedding model there. I tested the whole code path with a clearly labelled offline hashing stand-in (`EMBEDDER=smoke`, never used for any number below). That check confirmed everything that does not depend on the embeddings: 13 chunks at 400/60, **25 chunks** at 200/30, keyword baseline **9 of 12**, one identical invented answer for all 16 questions with the ungrounded prompt. The embedding-dependent figures below are **not measured by me**; run `python part_d4_rag.py` once with internet access, which prints them and writes `outputs/rag_eval.csv`, and paste the output into this section. `python part_d4_rag.py` also prints which embedder was used.

| Item | My measured value | Value in the brief (for comparison only) |
|---|---|---|
| (c) top-3 file hits / top-1 file hits (12 answerable) | run `part_d4_rag.py` | 12 / 12 and 12 / 12 |
| (c) answerable top-1 similarity range | run `part_d4_rag.py` | 0.334 to 0.637 |
| (c) unanswerable top-1 similarities | run `part_d4_rag.py` | 0.069, −0.047, 0.295, 0.304 |
| (c) keyword baseline top-1 (stop-word-filtered shared words, ties alphabetical) | **9 / 12** | 9 / 12 |
| (d) threshold = midpoint of lowest answerable and highest unanswerable top-1 | run `part_d4_rag.py` | ≈ 0.32 |
| (d) grounded answers containing the expected fact / fallbacks for unanswerable | run `part_d4_rag.py` | 12 / 12 and 4 / 4 |
| (d) ungrounded prompt | **one identical confident invented answer for all 16** (verified) | same |
| (e) 200/30: chunks / fact in top-3 / grounded answers with fact | **25** / run / run | 25 / 11 / 8 |

How the code decides, so the numbers can be audited: the rejection threshold is computed in the script as the midpoint between the lowest answerable and the highest unanswerable top-1 similarity, and the script prints the width of that window. With the brief's reference values the window is only about 0.03 wide, so the threshold has **very little margin**: the two highest unanswerable questions (≈ 0.30 in the brief) sit right next to the lowest answerable one. If a different embedding build flips a borderline question, report it rather than hiding it. `answer()` returns exactly `I don't have enough information to answer that.` without calling the model when the best similarity is below the threshold; otherwise it sends the `POLICY ASSISTANT … using only the context` system message and `CONTEXT: … QUESTION: …` user message and returns the answer and sources.

Why meaning-based search should beat keywords here (to be confirmed by your run): questions are worded differently from the policy ("top-up money deducted", "keeps breaking up") so shared words are few and generic, while embeddings match meaning; the unanswerable question closest to being mistaken for an answerable one is the one with the highest top-1 similarity in your run (a plausible candidate is the student-discount question, which shares offer/discount vocabulary with the retention-offers policy). Why smaller chunks lose information (to be confirmed by your run): at 200 characters a sentence is often cut in two, so the fact and the words that identify its topic land in different chunks and the retrieved chunk or the answer sentence is incomplete.

### 5. Retention Copilot (`copilot.py`)

For each of the 15 priority subscribers: `tenure_months` and the failed-recharge count are read from SQLite with SQL; the full feature row is rebuilt by `features.build_feature_row` (the same feature code Part B uses, with `None → NaN`); the subscriber is re-scored with `outputs/churn_model.joblib` and asserted equal to the file's probability to 4 decimals; risk band High ≥ 0.40, Medium ≥ 0.20, else Low; the segment comes from `outputs/segments.csv`; the top 3 chunks come from retrieval; the model gets the `RETENTION BRIEF` system message and the `FACTS: … POLICY CONTEXT: …` user message; the reply is validated with the Pydantic `RetentionBrief` model plus consistency checks (same subscriber_id and risk_band as sent, `policy_source` a real policy file), with the same retry approach as task 3. Output: `outputs/retention_briefs.jsonl`.

My run (Part B random forest; retrieval of the retention-offers chunks was confirmed in the run, but re-run after your embedding run so the file is produced with the real embedder):

| Result | Count |
|---|---|
| valid briefs | **15 / 15** (all on the first attempt) |
| High / Medium / Low | 14 / 1 / 0 (TP01015 has probability 0.4021, just above the 0.40 cut-off, so it is High on this build; TP01548 at 0.366 is the Medium one) |
| auto-renew setup call + 7 day grace extension | 4 |
| loyalty discount of 15 percent | 4 |
| free add-on pack for 2 months | 6 |
| "No retention offer applies" | 1 |

Rule check (every brief cites `retention_offers_policy.txt`, and all 15 follow the rule):

| Condition | Offer |
|---|---|
| High and ≥ 3 failed recharges | auto-renew setup call + 7 day grace extension |
| else High and tenure ≥ 12 months | loyalty discount of 15 percent on the next three recharges |
| else High | free add-on pack for 2 months |
| Medium or Low | no offer |

Examples: TP00798 (High, tenure 13, 3 failed) → setup call; TP02228 (High, tenure 22, 1 failed) → 15% discount; TP00986 (High, tenure 0, 0 failed) → free add-on pack; TP01548 (Medium) → no offer.

---

## Limitations and Next Steps

1. **Synthetic data.** Everything is generated by a script with a known churn formula, so real-world performance, feature effects and the high R² of the spend model (next-cycle spend is almost a deterministic function of plan and viewing) will not carry over.
2. **A single time window.** One snapshot (Oct 2025-Mar 2026) and one label month (April 2026). There is no check for seasonality or drift; next steps are a rolling-origin backtest over several months and monitoring of the score distribution.
3. **Deterministic mock instead of a real model.** The classifier, extractor and brief writer are rule-based simulations. Their "errors" are scripted, so the 97% few-shot accuracy and the 28 successful retries say little about how a real LLM would behave; the live-mode switch should be exercised with a real endpoint and a larger evaluation set.
4. **The priority list uses test-set subscribers.** Outcomes are already known, so it demonstrates the method and is not a forward-looking evaluation; a real list would score the current base.
5. **Thin retrieval-threshold margin and unverified embedding numbers.** Only about 0.03 separates the lowest answerable from the highest unanswerable similarity (per the brief's reference), so the threshold is fragile on other embedding builds. In my build environment the real embedding model could not be downloaded, so the numbers of Part D task 4(c)-(e) must be filled in from a local run (see the note in Part D task 4).
6. **Threshold and model choice are noisy.** The validation cost curve is nearly flat and the validation set holds only 103 churners; logistic regression has the lower test cost (INR 51,000 vs 54,900) even though the forest won on validation. A larger validation set, repeated cross-validated threshold selection, or probability calibration would make the choice firmer.
7. **No fairness or privacy review**, and the offers (loyalty discount, free pack) are not tested for causal uplift; an A/B test is needed before treating "at risk" as "will respond to an offer".
